/*
* UMB - Universal Modified  Bus Driver - simple USB driver modified for teaching purpose 
* date: 1 Feb 2013  
* 
* References: 
*  1. Linux Device Driver 3rd edition example USB driver source code
*  2. Understanding Linux Kernel 3rd edition
*  3. Various USB debugging resources
*  
* GNU General Public License 
* Copyright (C) 2013 Ka.Shrinivaasan (ka.shrinivaasan@gmail.com, Krishna iResearch)
* 
* Copyright attribution from Linux Device Driver 3rd edition :
* USB Skeleton driver - 2.0
* Copyright (C) 2001-2004 Greg Kroah-Hartman (greg@kroah.com)
*
*	This program is free software; you can redistribute it and/or
*	modify it under the terms of the GNU General Public License as
*	published by the Free Software Foundation, version 2.
*
* This driver is based on the 2.6.3 version of drivers/usb/usb-skeleton.c 
* but has been rewritten to be easy to read and use, as no locks are now
* needed anymore.
*
*/

/* 
 * Changes done for Linux Kernel 3.2.0:
 * 1.Removed BigKernelLock(BKL) and replaced it with a mutex
 * 2.Replaced usb_buffer_alloc() with usb_buffer_coherent
 * 3.Build errors fixed
 */

/*
#include <linux/config.h>
#include <linux/smp_lock.h>
*/
#include <linux/mutex.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/init.h>
#include <linux/slab.h>
#include <linux/module.h>
#include <linux/kref.h>
#include <linux/usb.h>
#include <asm/uaccess.h>

#define to_umb_driver(d) container_of(d, struct usb_umb, kref)

#define UMB_VENDOR_ID	0xcde0
#define UMB_PRODUCT_ID	0xabc0

struct mutex umb_mutex;

MODULE_LICENSE("GPL");

static struct usb_device_id umb_table[] = {
	{ USB_DEVICE(UMB_PRODUCT_ID, UMB_VENDOR_ID)},
	{ }
};

MODULE_DEVICE_TABLE(usb, umb_table);

static ssize_t umb_read(struct file* f, char __user *buffer, size_t count, loff_t* ppos);
static ssize_t umb_write(struct file *f, const char __user *user_buffer, size_t count, loff_t *ppos);
static void umb_probe(struct usb_interface *interface, const struct usb_device_id* id);
static void umb_disconnect(struct usb_interface *interface);
static int umb_release(struct inode* inode, struct file* file);
static void umb_delete(struct kref* kref);
static int umb_open(struct inode* inode, struct file* file);
static char* umb_devnode(struct device *dev, mode_t *mode);

#define USB_UMB_MINOR_BASE	192

static struct usb_driver umb_driver = {
	.name  = "USB-MD",
	.id_table = umb_table,
	.probe = umb_probe,
	.disconnect = umb_disconnect
};

static struct file_operations umb_fops = {
	.owner = THIS_MODULE,
	.read = umb_read,
	.write = umb_write,
	.open = umb_open,
	.release = umb_release
};

static struct usb_class_driver umb_class = {
		.name = "usb/umb%d",
		.fops = &umb_fops,
		/*.mode = S_IFCHR | S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH,*/
		.devnode = umb_devnode,
		.minor_base = USB_UMB_MINOR_BASE,
};

struct usb_umb {
	struct usb_device* udev;
	struct usb_interface* interface;
	unsigned char* bulk_in_buffer;
	/* 
	 * bulk_out_buffer added
	 * - ka.shrinivaasan 8 Feb 2013 
	 */
	unsigned char* bulk_out_buffer;
	size_t bulk_in_size;
	__u8 bulk_in_endpointAddr;
	__u8 bulk_out_endpointAddr;
	struct kref kref;
};

static ssize_t umb_read(struct file* f, char __user *buffer, size_t count, loff_t* ppos)
{
	struct usb_umb *dev;
	int retval = 0;
	
	dev = (struct usb_umb*)f->private_data;
	retval = usb_bulk_msg(dev->udev,
						usb_rcvbulkpipe(dev->udev, dev->bulk_in_endpointAddr),
						dev->bulk_in_buffer,
						min(dev->bulk_in_size, count),
						&count,
						HZ*10
						);
	copy_to_user(buffer, dev->bulk_in_buffer, count);
	return retval;
	
}

static void umb_write_bulk_callback(struct urb *urb, struct pt_regs *regs)
{
	dbg("in function %s and urb status is %d \n", __FUNCTION__, urb->status);
}

static ssize_t umb_write(struct file *f, const char __user *user_buffer, size_t count, loff_t *ppos)
{
	struct usb_umb *dev;
	int retval = 0;
	struct urb *urb = NULL;
	char *buf = NULL;
	
	dev = (struct usb_umb*)f->private_data;
	
	if (count == 0)
		return -1;
	
	/*alloc urb and buffer, copy from userspace*/
	urb = usb_alloc_urb(0, GFP_KERNEL);
	/*buf = usb_buffer_alloc(dev->udev, count, GFP_KERNEL, &urb->transfer_dma);*/
	buf = usb_alloc_coherent(dev->udev, count, GFP_KERNEL, &urb->transfer_dma);
	copy_from_user(buf, user_buffer, count);
	
	/*fill urb and submit */
	usb_fill_bulk_urb(urb, dev->udev, usb_sndbulkpipe(dev->udev, dev->bulk_out_endpointAddr),
						buf, count, umb_write_bulk_callback, dev);
	urb->transfer_flags |= URB_NO_TRANSFER_DMA_MAP;
	retval = usb_submit_urb(urb, GFP_KERNEL);
	usb_free_urb(urb);
	return count;
}

static char* umb_devnode(struct device *dev, mode_t *mode)
{
	return "mode";
}

static int umb_init(void)
{
	int result;
	result = usb_register(&umb_driver);
	printk(KERN_INFO "in init ...after usb_register(), result %d\n", result);
	return result;
}

static void umb_exit(void)
{
	usb_deregister(&umb_driver);
	printk(KERN_INFO "in exit\n");
	return 0;
}

static void umb_probe(struct usb_interface *interface, const struct usb_device_id* id)
{
	struct usb_umb* dev=NULL;
	struct usb_host_interface* iface_desc;
	struct usb_endpoint_descriptor* endpoint;
	size_t buffer_size;
	int i;
	int retval = -ENOMEM;
	
	dev=kmalloc(sizeof(struct usb_umb), GFP_KERNEL);
	memset(dev, 0x0, sizeof(struct usb_umb));
	kref_init(&dev->kref);
	
	dev->udev = usb_get_dev(interface_to_usbdev(interface));
	dev->interface = interface;
	
	iface_desc = interface->cur_altsetting;
	for(i=0; i < iface_desc->desc.bNumEndpoints; i++)
	{
		endpoint = &iface_desc->endpoint[i].desc;
		if(!dev->bulk_in_endpointAddr &&
				(endpoint->bEndpointAddress & USB_DIR_IN) &&
				((endpoint->bmAttributes & USB_ENDPOINT_XFERTYPE_MASK)
				 == USB_ENDPOINT_XFER_BULK))
		{
			buffer_size = endpoint->wMaxPacketSize;
			dev->bulk_in_size = buffer_size;
			dev->bulk_in_endpointAddr = endpoint->bEndpointAddress;
			dev->bulk_in_buffer = kmalloc(buffer_size, GFP_KERNEL);
		}
		if(!dev->bulk_out_endpointAddr &&
						(endpoint->bEndpointAddress & USB_DIR_OUT) &&
						((endpoint->bmAttributes & USB_ENDPOINT_XFERTYPE_MASK)
						 == USB_ENDPOINT_XFER_BULK))
		{
			dev->bulk_out_buffer = kmalloc(buffer_size,GFP_KERNEL);
			dev->bulk_out_endpointAddr= endpoint->bEndpointAddress;
		}
	}
	usb_set_intfdata(interface, dev);
	usb_register_dev(interface, &umb_class);
	return 0;
}

static void umb_disconnect(struct usb_interface *interface)
{
	struct usb_umb *dev;
	int minor = interface->minor;
	
	/*lock_kernel();*/
	mutex_lock(&umb_mutex);
	dev = usb_get_intfdata(interface);
	usb_set_intfdata(interface,NULL);
	usb_deregister_dev(interface, &umb_class);
	/*unlock_kernel();*/
	mutex_unlock(&umb_mutex);
	kref_put(&dev->kref, umb_delete);
}

static int umb_open(struct inode* inode, struct file* file)
{
	struct usb_umb *dev;
	struct usb_interface *interface;
	int subminor;
	int retval = 0;
	
	subminor = iminor(inode);
	
	interface = usb_find_interface(&umb_driver, subminor);
	dev = usb_get_intfdata(interface);
	
	kref_get(&dev->kref);
	
	file->private_data = dev;
	return retval;
}

static int umb_release(struct inode* inode, struct file* file)
{
	struct usb_umb *dev;
	dev = (struct usb_umb*)file->private_data;
	kref_put(&dev->kref, umb_delete);
}

static void umb_delete(struct kref* kref)
{
	struct usb_umb* dev = to_umb_driver(kref);
	usb_put_dev(dev->udev);
	kfree(dev->bulk_in_buffer);
	kfree(dev);
}

module_init(umb_init);
module_exit(umb_exit);

